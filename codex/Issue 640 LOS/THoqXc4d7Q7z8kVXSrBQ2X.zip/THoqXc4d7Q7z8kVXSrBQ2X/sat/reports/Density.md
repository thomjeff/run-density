# Fredericton Marathon — Density Report
**Schema:** 1.0.0
**Method:** segments_from_bins
**Date:** 2026-01-08 13:14:18
**Inputs:** bins.parquet, segments.parquet, segment_windows_from_bins.parquet
**App:** vv2.0.4

---

## Executive Summary
- **Peak Density:** 0.6920 p/m² (LOS C)
- **Peak Rate:** 1.75 p/s
- **Segments with Flags:** 6 / 6
- **Flagged Bins:** 210 / 3900
- **Operational Status:** 🔴 Action Required (Critical density/rate conditions detected)

- **Runner Experience Scores (RES):**
  - sat-elite: 5.00
  - sat-open: 5.00

> RES (Runner Experience Score) is a composite score (0.0-5.0) representing overall race experience, combining density and flow metrics. Higher scores indicate better runner experience.
> LOS (Level of Service) describes how comfortable runners are within a section — A means free-flowing, while E/F indicate crowding. Even when overall LOS is good, short-lived surges in runner flow can stress aid stations or intersections, requiring active flow management.

---

## Methodology & Inputs
- **Window Size:** 30 s; **Bin Size:** 0.2 km

### LOS and Rate Triggers (from Rulebook)
- **LOS thresholds** define crowding levels based on density (p/m²):
  - A: < 0.36 | B: 0.36–0.54 | C: 0.54–0.72 | D: 0.72–1.08 | E: 1.08–1.63 | F: > 1.63
- **Rate thresholds** define throughput risk based on flow references (persons/m/min):
  - Warning: 30.1 | Critical: 40.4

These thresholds come from the Fredericton Marathon rulebook and align with crowd management standards for mass participation events.

---

## Start Times & Cohorts
- **Elite 5K** — 08:00 (39 runners)
- **Open 5K** — 08:30 (550 runners)

> Bins may include runners from multiple events as waves overlap in time.

---

## Course Overview

| Segment | Label | Schema | Width (m) | Spatial Bins |
|----------|--------|--------|-----------|--------------|
| N1 | 5K Elite Lap 1 (Start to Queen/York) | N/A | 5.0 | 13 |
| N2 | 5K Elite Lap 2 (Queen/York to Queen/York) | N/A | 5.0 | 12 |
| N3 | 5K Elite Finish (Queen/York to Finish) | N/A | 5.0 | 1 |
| O1 | 5K Open Lap 1 (Start to Queen/York) | N/A | 5.0 | 13 |
| O2 | 5K Open Lap 2 (Queen/York to Queen/York) | N/A | 5.0 | 12 |
| O3 | 5K Open Finish (Queen/York to Finish) | N/A | 5.0 | 1 |

> Note: Each spatial bin is analyzed across 80 time windows (30-second intervals). Total space-time bins per segment = spatial bins × 80 (e.g., A1: 5 × 80 = 400; I1: 121 × 80 = 9,680).

---

## Flagged Segments

| Segment | Label | Flagged Bins | Total Bins | % | Worst Bin (km) | Time | Density (p/m²) | Rate (p/s) | Util% | LOS | Severity | Reason |
|----------|--------|--------------|------------|---|----------------|-------|----------------|-------------|-------|-----|-----------|---------|
| N1 | 5K Elite Lap 1 (Start to Queen/York) | 20 | 975 | 2.1% | 0.0-0.2 | 08:00 | 0.0390 | 0.955 | N/A | A | watch | none |
| N2 | 5K Elite Lap 2 (Queen/York to Queen/York) | 29 | 900 | 3.2% | 0.0-0.2 | 08:08 | 0.0180 | 0.440 | N/A | A | watch | none |
| N3 | 5K Elite Finish (Queen/York to Finish) | 4 | 75 | 5.3% | 0.0-0.2 | 08:16 | 0.0140 | 0.334 | N/A | A | watch | none |
| O1 | 5K Open Lap 1 (Start to Queen/York) | 48 | 975 | 4.9% | 0.0-0.2 | 08:30 | 0.6920 | 8.729 | N/A | C | critical | none |
| O2 | 5K Open Lap 2 (Queen/York to Queen/York) | 94 | 900 | 10.4% | 0.0-0.2 | 08:48 | 0.1650 | 1.990 | N/A | A | watch | none |
| O3 | 5K Open Finish (Queen/York to Finish) | 15 | 75 | 20.0% | 0.0-0.2 | 09:06 | 0.0990 | 1.116 | N/A | A | watch | none |

---

## Operational Heatmap

*Operational heatmap visualization will be added in a future release via new maps capability.*

This section will provide:
- Visual density/rate heatmaps across course segments
- Time-based animation of crowd flows
- Interactive bin-level detail views

---

## Bin-Level Detail

Detailed bin-by-bin breakdown for segments with operational intelligence flags:

### 5K Elite Lap 1 (Start to Queen/York) (N1)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:00 | 08:02 | 0.039 | 0.955 | A |
| 0.2 | 0.4 | 08:00 | 08:02 | 0.010 | 0.214 | A |
| 0.4 | 0.6 | 08:00 | 08:02 | 0.029 | 0.741 | A |
| 0.4 | 0.6 | 08:02 | 08:04 | 0.001 | 0.020 | A |
| 0.6 | 0.8 | 08:02 | 08:04 | 0.029 | 0.682 | A |
| 0.8 | 1.0 | 08:02 | 08:04 | 0.028 | 0.676 | A |
| 1.0 | 1.2 | 08:02 | 08:04 | 0.018 | 0.473 | A |
| 1.2 | 1.4 | 08:02 | 08:04 | 0.002 | 0.057 | A |
| 1.0 | 1.2 | 08:04 | 08:06 | 0.008 | 0.169 | A |
| 1.2 | 1.4 | 08:04 | 08:06 | 0.024 | 0.557 | A |
| 1.4 | 1.6 | 08:04 | 08:06 | 0.029 | 0.724 | A |
| 1.6 | 1.8 | 08:04 | 08:06 | 0.009 | 0.234 | A |
| 1.8 | 2.0 | 08:04 | 08:06 | 0.008 | 0.226 | A |
| 1.6 | 1.8 | 08:06 | 08:08 | 0.013 | 0.283 | A |
| 1.8 | 2.0 | 08:06 | 08:08 | 0.019 | 0.437 | A |
| 2.0 | 2.2 | 08:06 | 08:08 | 0.024 | 0.596 | A |
| 2.2 | 2.4 | 08:06 | 08:08 | 0.012 | 0.321 | A |
| 2.4 | 2.6 | 08:06 | 08:08 | 0.007 | 0.195 | A |
| 2.2 | 2.4 | 08:08 | 08:10 | 0.016 | 0.355 | A |
| 2.4 | 2.6 | 08:08 | 08:10 | 0.013 | 0.305 | A |

### 5K Elite Lap 2 (Queen/York to Queen/York) (N2)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:06 | 08:08 | 0.002 | 0.057 | A |
| 0.0 | 0.2 | 08:08 | 08:10 | 0.018 | 0.440 | A |
| 0.2 | 0.4 | 08:08 | 08:10 | 0.013 | 0.353 | A |
| 0.4 | 0.6 | 08:08 | 08:10 | 0.005 | 0.134 | A |
| 0.6 | 0.8 | 08:08 | 08:10 | 0.007 | 0.198 | A |
| 0.2 | 0.4 | 08:10 | 08:12 | 0.015 | 0.336 | A |
| 0.4 | 0.6 | 08:10 | 08:12 | 0.013 | 0.305 | A |
| 0.6 | 0.8 | 08:10 | 08:12 | 0.015 | 0.367 | A |
| 0.8 | 1.0 | 08:10 | 08:12 | 0.011 | 0.294 | A |
| 1.0 | 1.2 | 08:10 | 08:12 | 0.007 | 0.193 | A |
| 1.2 | 1.4 | 08:10 | 08:12 | 0.008 | 0.226 | A |
| 0.8 | 1.0 | 08:12 | 08:14 | 0.017 | 0.391 | A |
| 1.0 | 1.2 | 08:12 | 08:14 | 0.007 | 0.162 | A |
| 1.2 | 1.4 | 08:12 | 08:14 | 0.013 | 0.318 | A |
| 1.4 | 1.6 | 08:12 | 08:14 | 0.007 | 0.183 | A |
| 1.6 | 1.8 | 08:12 | 08:14 | 0.012 | 0.330 | A |
| 1.8 | 2.0 | 08:12 | 08:14 | 0.006 | 0.167 | A |
| 1.2 | 1.4 | 08:14 | 08:16 | 0.010 | 0.217 | A |
| 1.4 | 1.6 | 08:14 | 08:16 | 0.014 | 0.325 | A |
| 1.6 | 1.8 | 08:14 | 08:16 | 0.009 | 0.210 | A |
| 1.8 | 2.0 | 08:14 | 08:16 | 0.009 | 0.221 | A |
| 2.0 | 2.2 | 08:14 | 08:16 | 0.007 | 0.182 | A |
| 1.2 | 1.4 | 08:16 | 08:18 | 0.001 | 0.020 | A |
| 1.4 | 1.6 | 08:16 | 08:18 | 0.005 | 0.103 | A |
| 1.6 | 1.8 | 08:16 | 08:18 | 0.005 | 0.107 | A |
| 1.8 | 2.0 | 08:16 | 08:18 | 0.008 | 0.177 | A |
| 2.0 | 2.2 | 08:16 | 08:18 | 0.014 | 0.324 | A |
| 1.6 | 1.8 | 08:18 | 08:20 | 0.001 | 0.020 | A |
| 2.0 | 2.2 | 08:18 | 08:20 | 0.006 | 0.125 | A |

### 5K Elite Finish (Queen/York to Finish) (N3)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:14 | 08:16 | 0.010 | 0.278 | A |
| 0.0 | 0.2 | 08:16 | 08:18 | 0.014 | 0.334 | A |
| 0.0 | 0.2 | 08:18 | 08:20 | 0.008 | 0.172 | A |
| 0.0 | 0.2 | 08:20 | 08:22 | 0.001 | 0.020 | A |

### 5K Open Lap 1 (Start to Queen/York) (O1)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:30 | 08:32 | 0.692 | 8.729 | C |
| 0.2 | 0.4 | 08:30 | 08:32 | 0.153 | 2.448 | A |
| 0.4 | 0.6 | 08:30 | 08:32 | 0.006 | 0.139 | A |
| 0.0 | 0.2 | 08:32 | 08:34 | 0.064 | 0.593 | A |
| 0.2 | 0.4 | 08:32 | 08:34 | 0.563 | 6.511 | C |
| 0.4 | 0.6 | 08:32 | 08:34 | 0.360 | 5.054 | A |
| 0.6 | 0.8 | 08:32 | 08:34 | 0.085 | 1.506 | A |
| 0.8 | 1.0 | 08:32 | 08:34 | 0.025 | 0.513 | A |
| 1.0 | 1.2 | 08:32 | 08:34 | 0.002 | 0.049 | A |
| 0.2 | 0.4 | 08:34 | 08:36 | 0.037 | 0.302 | A |
| 0.4 | 0.6 | 08:34 | 08:36 | 0.356 | 3.770 | A |
| 0.6 | 0.8 | 08:34 | 08:36 | 0.416 | 5.309 | B |
| 0.8 | 1.0 | 08:34 | 08:36 | 0.179 | 2.733 | A |
| 1.0 | 1.2 | 08:34 | 08:36 | 0.070 | 1.260 | A |
| 1.2 | 1.4 | 08:34 | 08:36 | 0.033 | 0.670 | A |
| 0.6 | 0.8 | 08:36 | 08:38 | 0.200 | 1.949 | A |
| 0.8 | 1.0 | 08:36 | 08:38 | 0.372 | 4.422 | B |
| 1.0 | 1.2 | 08:36 | 08:38 | 0.256 | 3.485 | A |
| 1.2 | 1.4 | 08:36 | 08:38 | 0.116 | 1.826 | A |
| 1.4 | 1.6 | 08:36 | 08:38 | 0.069 | 1.235 | A |
| 1.6 | 1.8 | 08:36 | 08:38 | 0.031 | 0.620 | A |
| 0.8 | 1.0 | 08:38 | 08:40 | 0.139 | 1.292 | A |
| 1.0 | 1.2 | 08:38 | 08:40 | 0.259 | 2.936 | A |
| 1.2 | 1.4 | 08:38 | 08:40 | 0.285 | 3.580 | A |
| 1.4 | 1.6 | 08:38 | 08:40 | 0.165 | 2.342 | A |
| 1.6 | 1.8 | 08:38 | 08:40 | 0.094 | 1.507 | A |
| 1.8 | 2.0 | 08:38 | 08:40 | 0.055 | 0.977 | A |
| 1.0 | 1.2 | 08:40 | 08:42 | 0.110 | 0.996 | A |
| 1.2 | 1.4 | 08:40 | 08:42 | 0.176 | 1.898 | A |
| 1.4 | 1.6 | 08:40 | 08:42 | 0.272 | 3.271 | A |
| 1.6 | 1.8 | 08:40 | 08:42 | 0.190 | 2.525 | A |
| 1.8 | 2.0 | 08:40 | 08:42 | 0.116 | 1.703 | A |
| 2.0 | 2.2 | 08:40 | 08:42 | 0.073 | 1.179 | A |
| 1.4 | 1.6 | 08:42 | 08:44 | 0.112 | 1.154 | A |
| 1.6 | 1.8 | 08:42 | 08:44 | 0.233 | 2.679 | A |
| 1.8 | 2.0 | 08:42 | 08:44 | 0.207 | 2.618 | A |
| 2.0 | 2.2 | 08:42 | 08:44 | 0.143 | 1.966 | A |
| 2.2 | 2.4 | 08:42 | 08:44 | 0.090 | 1.355 | A |
| 2.4 | 2.6 | 08:42 | 08:44 | 0.055 | 0.893 | A |
| 1.6 | 1.8 | 08:44 | 08:46 | 0.103 | 1.025 | A |
| 1.8 | 2.0 | 08:44 | 08:46 | 0.166 | 1.864 | A |
| 2.0 | 2.2 | 08:44 | 08:46 | 0.207 | 2.494 | A |
| 2.2 | 2.4 | 08:44 | 08:46 | 0.167 | 2.200 | A |
| 2.4 | 2.6 | 08:44 | 08:46 | 0.092 | 1.300 | A |
| 2.0 | 2.2 | 08:46 | 08:48 | 0.121 | 1.324 | A |
| 2.2 | 2.4 | 08:46 | 08:48 | 0.179 | 2.082 | A |
| 2.4 | 2.6 | 08:46 | 08:48 | 0.157 | 1.982 | A |
| 2.4 | 2.6 | 08:48 | 08:50 | 0.153 | 1.736 | A |

### 5K Open Lap 2 (Queen/York to Queen/York) (O2)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:44 | 08:46 | 0.075 | 1.138 | A |
| 0.0 | 0.2 | 08:46 | 08:48 | 0.134 | 1.801 | A |
| 0.2 | 0.4 | 08:46 | 08:48 | 0.079 | 1.137 | A |
| 0.4 | 0.6 | 08:46 | 08:48 | 0.067 | 1.027 | A |
| 0.0 | 0.2 | 08:48 | 08:50 | 0.165 | 1.990 | A |
| 0.2 | 0.4 | 08:48 | 08:50 | 0.134 | 1.742 | A |
| 0.4 | 0.6 | 08:48 | 08:50 | 0.102 | 1.396 | A |
| 0.6 | 0.8 | 08:48 | 08:50 | 0.071 | 1.041 | A |
| 0.8 | 1.0 | 08:48 | 08:50 | 0.056 | 0.865 | A |
| 0.0 | 0.2 | 08:50 | 08:52 | 0.125 | 1.391 | A |
| 0.2 | 0.4 | 08:50 | 08:52 | 0.152 | 1.775 | A |
| 0.4 | 0.6 | 08:50 | 08:52 | 0.131 | 1.649 | A |
| 0.6 | 0.8 | 08:50 | 08:52 | 0.123 | 1.631 | A |
| 0.8 | 1.0 | 08:50 | 08:52 | 0.076 | 1.066 | A |
| 1.0 | 1.2 | 08:50 | 08:52 | 0.058 | 0.859 | A |
| 0.2 | 0.4 | 08:52 | 08:54 | 0.085 | 0.928 | A |
| 0.4 | 0.6 | 08:52 | 08:54 | 0.151 | 1.730 | A |
| 0.6 | 0.8 | 08:52 | 08:54 | 0.123 | 1.494 | A |
| 0.8 | 1.0 | 08:52 | 08:54 | 0.122 | 1.581 | A |
| 1.0 | 1.2 | 08:52 | 08:54 | 0.093 | 1.257 | A |
| 1.2 | 1.4 | 08:52 | 08:54 | 0.066 | 0.942 | A |
| 0.6 | 0.8 | 08:54 | 08:56 | 0.127 | 1.432 | A |
| 0.8 | 1.0 | 08:54 | 08:56 | 0.128 | 1.508 | A |
| 1.0 | 1.2 | 08:54 | 08:56 | 0.106 | 1.332 | A |
| 1.2 | 1.4 | 08:54 | 08:56 | 0.110 | 1.445 | A |
| 1.4 | 1.6 | 08:54 | 08:56 | 0.082 | 1.132 | A |
| 1.6 | 1.8 | 08:54 | 08:56 | 0.052 | 0.752 | A |
| 0.8 | 1.0 | 08:56 | 08:58 | 0.098 | 1.088 | A |
| 1.0 | 1.2 | 08:56 | 08:58 | 0.134 | 1.550 | A |
| 1.2 | 1.4 | 08:56 | 08:58 | 0.103 | 1.258 | A |
| 1.4 | 1.6 | 08:56 | 08:58 | 0.101 | 1.308 | A |
| 1.6 | 1.8 | 08:56 | 08:58 | 0.090 | 1.201 | A |
| 1.8 | 2.0 | 08:56 | 08:58 | 0.056 | 0.784 | A |
| 1.2 | 1.4 | 08:58 | 09:00 | 0.131 | 1.490 | A |
| 1.4 | 1.6 | 08:58 | 09:00 | 0.100 | 1.190 | A |
| 1.6 | 1.8 | 08:58 | 09:00 | 0.095 | 1.195 | A |
| 1.8 | 2.0 | 08:58 | 09:00 | 0.099 | 1.295 | A |
| 2.0 | 2.2 | 08:58 | 09:00 | 0.071 | 0.965 | A |
| 1.2 | 1.4 | 09:00 | 09:02 | 0.051 | 0.547 | A |
| 1.4 | 1.6 | 09:00 | 09:02 | 0.109 | 1.227 | A |
| 1.6 | 1.8 | 09:00 | 09:02 | 0.111 | 1.294 | A |
| 1.8 | 2.0 | 09:00 | 09:02 | 0.086 | 1.053 | A |
| 2.0 | 2.2 | 09:00 | 09:02 | 0.088 | 1.134 | A |
| 1.2 | 1.4 | 09:02 | 09:04 | 0.050 | 0.498 | A |
| 1.4 | 1.6 | 09:02 | 09:04 | 0.039 | 0.413 | A |
| 1.6 | 1.8 | 09:02 | 09:04 | 0.082 | 0.910 | A |
| 1.8 | 2.0 | 09:02 | 09:04 | 0.122 | 1.402 | A |
| 2.0 | 2.2 | 09:02 | 09:04 | 0.080 | 0.959 | A |
| 1.2 | 1.4 | 09:04 | 09:06 | 0.033 | 0.314 | A |
| 1.4 | 1.6 | 09:04 | 09:06 | 0.051 | 0.505 | A |
| 1.6 | 1.8 | 09:04 | 09:06 | 0.033 | 0.345 | A |
| 1.8 | 2.0 | 09:04 | 09:06 | 0.059 | 0.645 | A |
| 2.0 | 2.2 | 09:04 | 09:06 | 0.112 | 1.270 | A |
| 1.2 | 1.4 | 09:06 | 09:08 | 0.030 | 0.266 | A |
| 1.4 | 1.6 | 09:06 | 09:08 | 0.027 | 0.255 | A |
| 1.6 | 1.8 | 09:06 | 09:08 | 0.048 | 0.473 | A |
| 1.8 | 2.0 | 09:06 | 09:08 | 0.033 | 0.339 | A |
| 2.0 | 2.2 | 09:06 | 09:08 | 0.045 | 0.486 | A |
| 0.8 | 1.0 | 09:08 | 09:10 | 0.025 | 0.190 | A |
| 1.4 | 1.6 | 09:08 | 09:10 | 0.028 | 0.249 | A |
| 1.6 | 1.8 | 09:08 | 09:10 | 0.025 | 0.234 | A |
| 1.8 | 2.0 | 09:08 | 09:10 | 0.043 | 0.422 | A |
| 2.0 | 2.2 | 09:08 | 09:10 | 0.036 | 0.365 | A |
| 1.0 | 1.2 | 09:10 | 09:12 | 0.025 | 0.190 | A |
| 1.4 | 1.6 | 09:10 | 09:12 | 0.022 | 0.186 | A |
| 1.6 | 1.8 | 09:10 | 09:12 | 0.024 | 0.212 | A |
| 1.8 | 2.0 | 09:10 | 09:12 | 0.022 | 0.203 | A |
| 2.0 | 2.2 | 09:10 | 09:12 | 0.043 | 0.420 | A |
| 1.2 | 1.4 | 09:12 | 09:14 | 0.025 | 0.190 | A |
| 1.4 | 1.6 | 09:12 | 09:14 | 0.018 | 0.144 | A |
| 1.6 | 1.8 | 09:12 | 09:14 | 0.021 | 0.177 | A |
| 1.8 | 2.0 | 09:12 | 09:14 | 0.023 | 0.202 | A |
| 2.0 | 2.2 | 09:12 | 09:14 | 0.022 | 0.203 | A |
| 1.2 | 1.4 | 09:14 | 09:16 | 0.008 | 0.059 | A |
| 1.4 | 1.6 | 09:14 | 09:16 | 0.026 | 0.198 | A |
| 1.6 | 1.8 | 09:14 | 09:16 | 0.015 | 0.121 | A |
| 1.8 | 2.0 | 09:14 | 09:16 | 0.021 | 0.177 | A |
| 2.0 | 2.2 | 09:14 | 09:16 | 0.022 | 0.193 | A |
| 1.4 | 1.6 | 09:16 | 09:18 | 0.011 | 0.082 | A |
| 1.6 | 1.8 | 09:16 | 09:18 | 0.025 | 0.192 | A |
| 1.8 | 2.0 | 09:16 | 09:18 | 0.013 | 0.105 | A |
| 2.0 | 2.2 | 09:16 | 09:18 | 0.020 | 0.168 | A |
| 2.2 | 2.2 | 09:16 | 09:18 | 0.002 | 0.017 | A |
| 1.6 | 1.8 | 09:18 | 09:20 | 0.013 | 0.097 | A |
| 1.8 | 2.0 | 09:18 | 09:20 | 0.023 | 0.177 | A |
| 2.0 | 2.2 | 09:18 | 09:20 | 0.015 | 0.122 | A |
| 2.2 | 2.2 | 09:18 | 09:20 | 0.003 | 0.025 | A |
| 1.8 | 2.0 | 09:20 | 09:22 | 0.017 | 0.127 | A |
| 2.0 | 2.2 | 09:20 | 09:22 | 0.019 | 0.147 | A |
| 2.2 | 2.2 | 09:20 | 09:22 | 0.001 | 0.008 | A |
| 2.0 | 2.2 | 09:22 | 09:24 | 0.018 | 0.135 | A |
| 2.2 | 2.2 | 09:22 | 09:24 | 0.002 | 0.015 | A |
| 2.0 | 2.2 | 09:24 | 09:26 | 0.002 | 0.015 | A |
| 2.2 | 2.2 | 09:24 | 09:26 | 0.002 | 0.015 | A |

### 5K Open Finish (Queen/York to Finish) (O3)

| Start (km) | End (km) | Start (t) | End (t) | Density (p/m²) | Rate (p/s) | LOS |
|------------|----------|-----------|---------|----------------|-------------|-----|
| 0.0 | 0.2 | 08:58 | 09:00 | 0.052 | 0.740 | A |
| 0.0 | 0.2 | 09:00 | 09:02 | 0.082 | 1.094 | A |
| 0.0 | 0.2 | 09:02 | 09:04 | 0.074 | 0.938 | A |
| 0.0 | 0.2 | 09:04 | 09:06 | 0.090 | 1.066 | A |
| 0.0 | 0.2 | 09:06 | 09:08 | 0.099 | 1.116 | A |
| 0.0 | 0.2 | 09:08 | 09:10 | 0.036 | 0.386 | A |
| 0.0 | 0.2 | 09:10 | 09:12 | 0.030 | 0.302 | A |
| 0.0 | 0.2 | 09:12 | 09:14 | 0.037 | 0.361 | A |
| 0.0 | 0.2 | 09:14 | 09:16 | 0.020 | 0.184 | A |
| 0.0 | 0.2 | 09:16 | 09:18 | 0.021 | 0.184 | A |
| 0.0 | 0.2 | 09:18 | 09:20 | 0.016 | 0.136 | A |
| 0.0 | 0.2 | 09:20 | 09:22 | 0.016 | 0.130 | A |
| 0.0 | 0.2 | 09:22 | 09:24 | 0.017 | 0.131 | A |
| 0.0 | 0.2 | 09:24 | 09:26 | 0.019 | 0.144 | A |
| 0.0 | 0.2 | 09:26 | 09:28 | 0.004 | 0.029 | A |

---

## Segment Details

### 5K Elite Lap 1 (Start to Queen/York) (N1)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 975
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.0390 p/m² (LOS A), Rate 0.19 p/s
- **Worst Bin:** 0.0-0.2 km at 08:00 — watch (none)
- **Mitigations:** No mitigations required

### 5K Elite Lap 2 (Queen/York to Queen/York) (N2)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 900
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.0180 p/m² (LOS A), Rate 0.09 p/s
- **Worst Bin:** 0.0-0.2 km at 08:08 — watch (none)
- **Mitigations:** No mitigations required

### 5K Elite Finish (Queen/York to Finish) (N3)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 75
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.0140 p/m² (LOS A), Rate 0.07 p/s
- **Worst Bin:** 0.0-0.2 km at 08:16 — watch (none)
- **Mitigations:** No mitigations required

### 5K Open Lap 1 (Start to Queen/York) (O1)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 975
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.6920 p/m² (LOS C), Rate 1.75 p/s
- **Worst Bin:** 0.0-0.2 km at 08:30 — critical (none)
- **Mitigations:** No mitigations required

### 5K Open Lap 2 (Queen/York to Queen/York) (O2)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 900
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.1650 p/m² (LOS A), Rate 0.40 p/s
- **Worst Bin:** 0.0-0.2 km at 08:48 — watch (none)
- **Mitigations:** No mitigations required

### 5K Open Finish (Queen/York to Finish) (O3)
- **Schema:** on_course_open · **Width:** 5.0 m · **Bins:** 75
- **Active:** 08:00 → 10:30
- **Peaks:** Density 0.0990 p/m² (LOS A), Rate 0.22 p/s
- **Worst Bin:** 0.0-0.2 km at 09:06 — watch (none)
- **Mitigations:** No mitigations required

---

## Mitigations


---

## Appendix

### Definitions of Metrics
- **Density (ρ):** Areal density in persons per square meter (p/m²)
- **Rate (q):** Throughput rate in persons per second (p/s)
- **Rate per meter per minute:** (rate / width_m) × 60 in persons/m/min
- **Utilization (%):** Current flow rate / reference flow rate (critical). Shows "N/A" when \`flow_ref.critical\` is not defined for the segment schema in the rulebook.
- **LOS (Level of Service):** Crowd comfort class (A–F)
- **Bin:** Space–time cell [segment_id, start_km–end_km, t_start–t_end]

### LOS Thresholds
| LOS | Density Range (p/m²) | Description |
|-----|---------------------|-------------|
| A | 0.00 - 0.36 | Free Flow |
| B | 0.36 - 0.54 | Comfortable |
| C | 0.54 - 0.72 | Moderate |
| D | 0.72 - 1.08 | Dense |
| E | 1.08 - 1.63 | Very Dense |
| F | 1.63+ | Extremely Dense |

### Trigger Logic & Severity
- **los_high:** Density ≥ LOS C threshold
- **rate_high:** Rate per m per min ≥ warning threshold
- **both:** Both density and rate conditions met
- **Severity:** critical > watch > none

### Terminology Notes
- "Rate" = persons/s (formerly "Flow")
- Note: operational heatmap to be added in future release
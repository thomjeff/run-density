# Report rendering diff (conceptual)

## Before (per-segment block)
Peak Crowd Density: 1.01 runners/m² [D]
Peak Window (clock): 07:02–07:04

## After
Peak Density: 1.01 runners/m² [D]
Peak Flow:    82 runners/min/m        # only if flow_enabled for schema
Peak Window:  07:02–07:04

Mitigations:
- Hold next wave 30–60s
- Shorten pulse / narrow gate for 1–2 minutes

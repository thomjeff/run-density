# Test 1 Artifacts - E2E/No Bins

Generated: 2025-09-18 13:53 UTC
Configuration: 4CPU/4GB/600s Cloud Run
Status: ✅ ALL TESTS PASSED

## Files Included:
- map_data_2025-09-18-1353.json - Map dataset from CI E2E test

## Test Results:
- ✅ Health endpoint: OK
- ✅ Ready endpoint: OK  
- ✅ Density report API: OK
- ✅ Temporal flow report API: OK
- ✅ Cloud Run deployment: 100% traffic on new revision
- ✅ GCS file generation: Working correctly

## Next Step:
Ready for Test 2: Bins Enabled

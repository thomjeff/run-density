"""
Common utilities for Run-Density application.

This module provides shared functionality used across the application,
including configuration loading and utility functions.
"""


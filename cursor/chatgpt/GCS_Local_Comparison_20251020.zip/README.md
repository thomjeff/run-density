# GCS vs Local Data Comparison for UI Debugging

## Issue Summary

After E2E testing completed successfully on Cloud Run (2025-10-20 20:58:00 UTC), the UI is still displaying incorrect/zero values despite:
- ✅ Backend APIs returning correct data (logs show: "1875 flagged bins, 17 flagged segments")
- ✅ All 7 UI artifacts present in Cloud Storage
- ✅ Cloud Run logs showing correct API responses

## What's in This Package

### `/gcs/` - Files from Cloud Storage
Downloaded from `gs://run-density-reports/` at 2025-10-20 21:10 UTC (after E2E completion):

**artifacts/ui/** (7 files):
- flags.json (contains 17 segments, 1875 total flagged bins)
- flow.json
- health.json
- meta.json
- schema_density.json
- segment_metrics.json (22 segments with metrics)
- segments.geojson

**reports/**:
- 2025-10-20-2053-Density.md (latest Density report from Cloud Run)
- 2025-10-20-2058-Flow.md (latest Flow report from Cloud Run)
- 2025-10-20-2058-Flow.csv
- bins.parquet

### `/local/` - Files from Local E2E Run
From last successful local E2E run (2025-10-20 12:24 local time):

**artifacts/ui/** (same 7 files):
- flags.json
- flow.json
- health.json
- meta.json
- schema_density.json
- segment_metrics.json
- segments.geojson

**reports/**:
- 2025-10-20-1224-Density.md (local Density report)
- 2025-10-20-1226-Flow.md (local Flow report)
- 2025-10-20-1226-Flow.csv
- bins.parquet

## Data Verification Already Done

### ✅ Confirmed Matching:
- **flags.json**: First 20 lines of GCS and local are identical
  - Segment A1: 37 flagged bins, worst_severity: "watch"
  - Segment A2: 55 flagged bins, worst_severity: "watch"
  - Total: 1875 flagged bins across 17 segments

- **Dashboard API Response** (from Cloud Run logs at 21:03:45):
  ```
  Loaded flags data: <class 'list'>, length: 17
  Calculated bins_flagged: 1875 from 17 flag entries
  Dashboard summary: 22 segments, 1898 runners, status=action_required
  ```

- **API Endpoints Working**:
  - `/api/dashboard/summary` - returning correct totals
  - `/api/density/segments` - returning 22 segments with metrics
  - `/api/segments/geojson` - returning 22 enriched features

## UI Issues Reported by User

Despite correct backend data, the UI is still showing:

### Health Page:
- ❌ Environment shows "Local" instead of Cloud Run URL

### Reports Page:
- ❌ Empty/not displaying reports

### Flow Page:
- ✅ Appears okay (surprisingly)

### Density Page:
- ❌ Name showing ID instead of label
- ❌ No active window displayed
- ❌ Zero values for: peak density, peak rate, utilization, flag, worst bin
- ❌ Schema showing hardcoded "on_course_open" for all segments

### Segments Page:
- ❌ Missing data: ID, length, width, direction, LOS, peak density, peak rate

### Dashboard:
- ❌ Zero for: flagged bins, overtaking segments, co-presence
- ❌ Hardcoded event cohorts

## Questions for Analysis

1. **Data Discrepancy**: The backend APIs are returning correct data (confirmed in logs), but the UI is displaying zeros. Is there a frontend JavaScript parsing issue?

2. **Storage Path**: UI artifacts are in `gs://run-density-reports/artifacts/2025-10-20/ui/` but the `StorageService` might be looking elsewhere. How does `load_ui_artifact()` construct the GCS path?

3. **Environment Detection**: The health page shows "Local" environment. What determines this? Is it reading from `meta.json`?

4. **API Integration**: The frontend JavaScript should be calling the APIs (e.g., `/api/dashboard/summary`), but is it parsing the responses correctly?

5. **Caching**: Could there be browser caching or frontend build artifacts that need clearing?

6. **Date/Run ID**: Is the frontend looking for the correct date directory (2025-10-20)?

## Request for ChatGPT

Please analyze the GCS and local files to:

1. Verify data parity between GCS and local artifacts
2. Identify any discrepancies in the data structure or values
3. Determine why the UI would show zeros when the backend APIs are returning correct data
4. Suggest specific debugging steps for the frontend-backend integration
5. Check if there are any schema mismatches or field name issues that could cause parsing failures

## Technical Context

- **Application**: Run Density Analysis System
- **Version**: v1.6.42
- **Cloud Run URL**: https://run-density-ln4r3sfkha-uc.a.run.app
- **Storage**: Google Cloud Storage (gs://run-density-reports/)
- **Storage Service**: `app/storage_service.py` with `load_ui_artifact()` method
- **Frontend**: Jinja2 templates + JavaScript fetching from REST APIs
- **Backend**: FastAPI Python application

## Recent Changes (Issue 283-288)

- Implemented Single Source of Truth (SSOT) for flagging logic
- Created `StorageService` to abstract local/cloud storage
- Updated all API endpoints to use `storage_service.load_ui_artifact()`
- Fixed Docker image to include templates directory
- Fixed WIF authentication for GCS uploads in CI/CD

## E2E Test Evidence

From Cloud Run logs (2025-10-20 20:54:33):
```
✅ New density report generated in 5.12s
📊 Summary: 1875 flagged bins, 17 flagged segments
```

From Cloud Run logs (2025-10-20 21:03:45):
```
INFO:app.routes.api_dashboard:Calculated bins_flagged: 1875 from 17 flag entries
INFO:app.routes.api_dashboard:Dashboard summary: 22 segments, 1898 runners, status=action_required
```

---

**Package Created**: 2025-10-20 21:10 UTC
**Purpose**: Debug UI data display issues despite correct backend API responses

